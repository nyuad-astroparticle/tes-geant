#
# Do not call this directly, use
# 
#   eval `./setup`
#
export CRYHOME=$1
export CRYDATAPATH=$1/data

